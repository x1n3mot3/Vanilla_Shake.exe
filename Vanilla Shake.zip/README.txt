██╗   ██╗ █████╗ ███╗   ██╗██╗██╗     ██╗      █████╗              
██║   ██║██╔══██╗████╗  ██║██║██║     ██║     ██╔══██╗             
██║   ██║███████║██╔██╗ ██║██║██║     ██║     ███████║             
╚██╗ ██╔╝██╔══██║██║╚██╗██║██║██║     ██║     ██╔══██║             
 ╚████╔╝ ██║  ██║██║ ╚████║██║███████╗███████╗██║  ██║             
  ╚═══╝  ╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝╚══════╝╚══════╝╚═╝  ╚═╝             
                                                                   
███████╗██╗  ██╗ █████╗ ██╗  ██╗███████╗   ███████╗██╗  ██╗███████╗
██╔════╝██║  ██║██╔══██╗██║ ██╔╝██╔════╝   ██╔════╝╚██╗██╔╝██╔════╝
███████╗███████║███████║█████╔╝ █████╗     █████╗   ╚███╔╝ █████╗  
╚════██║██╔══██║██╔══██║██╔═██╗ ██╔══╝     ██╔══╝   ██╔██╗ ██╔══╝  
███████║██║  ██║██║  ██║██║  ██╗███████╗██╗███████╗██╔╝ ██╗███████╗
╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝╚══════╝╚═╝  ╚═╝╚══════╝
Vanilla Shake.exe by x1n3mot3
yep, TFW and TFW- programming language comeback (a language i made that is not avalible online)
This malware is very dangerous and should not be tested on a real Computer.
GDI effects work on Windows 11, Windows 10, Windows 8.1 and Windows 8
GDI effects do NOT work on Windows 7, Windows Vista and Windows XP
Made with: TFW and TFW- Programming language
Requires: Source code (the folder name is "TempPF")
Tip: You can keep the source code "hidden", and the malware will still find it. As long as the malware is in the same location as the source code.
enjoy :D