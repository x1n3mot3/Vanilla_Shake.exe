#include <windows.h>
#include <cstdlib>
#include <ctime>

int main()
{
    ShowWindow(
        GetConsoleWindow(),
        SW_HIDE
    );

    srand((unsigned)time(NULL));

    HDC hdc = GetDC(NULL);

    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);

    SetBkMode(hdc, TRANSPARENT);

    const char* messages[] =
    {
        "Vanilla!",
        "WScript-like",
        "Are u sure abt ts?"
    };

    while(true)
    {
        // Colorful background
        HBRUSH bg = CreateSolidBrush(
            RGB(
                rand()%256,
                rand()%256,
                rand()%256
            )
        );

        RECT screen =
        {
            0,
            0,
            sw,
            sh
        };

        FillRect(
            hdc,
            &screen,
            bg
        );

        DeleteObject(bg);

        // Text everywhere
        for(int i = 0; i < 400; i++)
        {
            int rotation =
                (rand()%4) * 900;

            HFONT font =
                CreateFontA(
                    rand()%150 + 10,
                    rand()%80 - 20,
                    rotation,
                    rotation,
                    FW_HEAVY,
                    FALSE,
                    FALSE,
                    FALSE,
                    ANSI_CHARSET,
                    OUT_DEFAULT_PRECIS,
                    CLIP_DEFAULT_PRECIS,
                    DEFAULT_QUALITY,
                    DEFAULT_PITCH,
                    "Impact"
                );

            SelectObject(hdc, font);

            SetTextColor(
                hdc,
                RGB(
                    255 - rand()%128,
                    255 - rand()%128,
                    255 - rand()%128
                )
            );

            const char* text =
                messages[rand()%3];

            TextOutA(
                hdc,
                rand()%sw,
                rand()%sh,
                text,
                lstrlenA(text)
            );

            DeleteObject(font);
        }

        Sleep(50);
    }

    ReleaseDC(NULL, hdc);
    return 0;
}
