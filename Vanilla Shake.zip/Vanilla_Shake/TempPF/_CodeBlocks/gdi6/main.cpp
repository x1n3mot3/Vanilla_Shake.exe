#include <windows.h>
#include <cstdlib>
#include <ctime>

int main()
{
    ShowWindow(
        GetConsoleWindow(),
        SW_HIDE
    );

    srand((unsigned)time(NULL));

    HDC hdc = GetDC(NULL);

    int sw =
        GetSystemMetrics(
            SM_CXSCREEN
        );

    int sh =
        GetSystemMetrics(
            SM_CYSCREEN
        );

    while(true)
    {
        // Gentle shake
        BitBlt(
            hdc,
            rand()%7 - 3,
            rand()%7 - 3,
            sw,
            sh,
            hdc,
            0,
            0,
            SRCCOPY
        );

        // Little moons
        for(int i = 0; i < 20; i++)
        {
            int x = rand()%sw;
            int y = rand()%sh;

            int size =
                rand()%40 + 15;

            HBRUSH moon =
                CreateSolidBrush(
                    RGB(
                        230,
                        230,
                        230
                    )
                );

            SelectObject(
                hdc,
                moon
            );

            Ellipse(
                hdc,
                x,
                y,
                x + size,
                y + size
            );

            DeleteObject(moon);

            // Tiny crater
            HBRUSH crater =
                CreateSolidBrush(
                    RGB(
                        180,
                        180,
                        180
                    )
                );

            SelectObject(
                hdc,
                crater
            );

            Ellipse(
                hdc,
                x + size/4,
                y + size/4,
                x + size/2,
                y + size/2
            );

            DeleteObject(crater);
        }

        Sleep(20);
    }

    ReleaseDC(NULL, hdc);
    return 0;
}
