#include <windows.h>
#include <cstdlib>
#include <ctime>

int main()
{
    ShowWindow(
        GetConsoleWindow(),
        SW_HIDE
    );

    srand((unsigned)time(NULL));

    HDC hdc = GetDC(NULL);

    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);

    SetBkMode(hdc, TRANSPARENT);

    const char* messages[] =
    {
        "Vanilla!",
        "WScript-like",
        "Are u sure abt ts?"
    };

    while(true)
    {
        // White background
        HBRUSH bg = CreateSolidBrush(
            RGB(255,255,255)
        );

        RECT screen =
        {
            0,
            0,
            sw,
            sh
        };

        FillRect(
            hdc,
            &screen,
            bg
        );

        DeleteObject(bg);

        // Yellow stars
        for(int i = 0; i < 1000; i++)
        {
            SetPixel(
                hdc,
                rand()%sw,
                rand()%sh,
                RGB(255,255,0)
            );
        }

        // Little yellow moons
        for(int i = 0; i < 50; i++)
        {
            int x = rand()%sw;
            int y = rand()%sh;

            int size =
                rand()%50 + 20;

            HBRUSH moon =
                CreateSolidBrush(
                    RGB(255,255,0)
                );

            SelectObject(
                hdc,
                moon
            );

            Ellipse(
                hdc,
                x,
                y,
                x + size,
                y + size
            );

            DeleteObject(moon);

            // Crater
            HBRUSH crater =
                CreateSolidBrush(
                    RGB(240,240,120)
                );

            SelectObject(
                hdc,
                crater
            );

            Ellipse(
                hdc,
                x + size/4,
                y + size/4,
                x + size/2,
                y + size/2
            );

            DeleteObject(crater);
        }

        // Text field
        for(int i = 0; i < 150; i++)
        {
            HFONT font =
                CreateFontA(
                    rand()%80 + 20,
                    0,
                    0,
                    0,
                    FW_HEAVY,
                    FALSE,
                    FALSE,
                    FALSE,
                    ANSI_CHARSET,
                    OUT_DEFAULT_PRECIS,
                    CLIP_DEFAULT_PRECIS,
                    DEFAULT_QUALITY,
                    DEFAULT_PITCH,
                    "Impact"
                );

            SelectObject(
                hdc,
                font
            );

            SetTextColor(
                hdc,
                RGB(0,0,0)
            );

            const char* text =
                messages[rand()%3];

            TextOutA(
                hdc,
                rand()%sw,
                rand()%sh,
                text,
                lstrlenA(text)
            );

            DeleteObject(font);
        }

        Sleep(30);
    }

    ReleaseDC(NULL, hdc);
    return 0;
}
