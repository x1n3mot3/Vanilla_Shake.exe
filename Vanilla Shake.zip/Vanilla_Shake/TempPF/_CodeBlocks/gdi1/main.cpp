#include <windows.h>
#include <cstdlib>
#include <ctime>

int main()
{
    ShowWindow(
        GetConsoleWindow(),
        SW_HIDE
    );

    srand((unsigned)time(NULL));

    HDC hdc = GetDC(NULL);

    int sw =
        GetSystemMetrics(SM_CXSCREEN);

    int sh =
        GetSystemMetrics(SM_CYSCREEN);

    while(true)
    {
        int shakeX =
            rand() % 7 - 3;

        int shakeY =
            rand() % 7 - 3;

        BitBlt(
            hdc,
            shakeX,
            shakeY,
            sw,
            sh,
            hdc,
            0,
            0,
            SRCCOPY
        );

        Sleep(20);
    }

    ReleaseDC(NULL, hdc);
    return 0;
}
