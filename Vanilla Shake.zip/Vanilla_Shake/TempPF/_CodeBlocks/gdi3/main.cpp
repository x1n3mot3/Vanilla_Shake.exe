#include <windows.h>
#include <cstdlib>
#include <ctime>

int main()
{
    ShowWindow(
        GetConsoleWindow(),
        SW_HIDE
    );

    srand((unsigned)time(NULL));

    HDC hdc = GetDC(NULL);

    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);

    SetBkMode(
        hdc,
        TRANSPARENT
    );

    const char* messages[] =
    {
        "Vanilla!",
        "WScript-like",
        "Are u sure abt ts?"
    };

    while(true)
    {
        // Horizontal BitBlt slices
        for(int y = 0; y < sh; y += 4)
        {
            BitBlt(
                hdc,
                rand()%101 - 50,
                y,
                sw,
                4,
                hdc,
                0,
                y,
                SRCCOPY
            );
        }

        // Text field
        for(int i = 0; i < 150; i++)
        {
            int rotation =
                (rand()%4) * 900;

            HFONT font =
                CreateFontA(
                    rand()%120 + 20,
                    rand()%60 - 10,
                    rotation,
                    rotation,
                    FW_HEAVY,
                    FALSE,
                    FALSE,
                    FALSE,
                    ANSI_CHARSET,
                    OUT_DEFAULT_PRECIS,
                    CLIP_DEFAULT_PRECIS,
                    DEFAULT_QUALITY,
                    DEFAULT_PITCH,
                    "Impact"
                );

            SelectObject(
                hdc,
                font
            );

            SetTextColor(
                hdc,
                (rand()%2)
                ? RGB(255,0,0)
                : RGB(0,100,255)
            );

            const char* text =
                messages[rand()%3];

            TextOutA(
                hdc,
                rand()%sw,
                rand()%sh,
                text,
                lstrlenA(text)
            );

            DeleteObject(font);
        }

        Sleep(10);
    }

    ReleaseDC(NULL, hdc);
    return 0;
}
