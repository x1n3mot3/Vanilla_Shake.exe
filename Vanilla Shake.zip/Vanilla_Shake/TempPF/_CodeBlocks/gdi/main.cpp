#include <windows.h>
#include <cstdlib>
#include <ctime>

int main()
{
    ShowWindow(
        GetConsoleWindow(),
        SW_HIDE
    );

    srand((unsigned)time(NULL));

    HDC hdc = GetDC(NULL);

    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);

    HICON infoIcon =
        LoadIcon(NULL, IDI_INFORMATION);

    while(true)
    {
        // Red background
        HBRUSH bg =
            CreateSolidBrush(
                RGB(255,0,0)
            );

        RECT screen =
        {
            0,
            0,
            sw,
            sh
        };

        FillRect(
            hdc,
            &screen,
            bg
        );

        DeleteObject(bg);

        // Information icon storm
        for(int i = 0; i < 1500; i++)
        {
            int size =
                rand()%200 + 16;

            DrawIconEx(
                hdc,
                rand()%sw,
                rand()%sh,
                infoIcon,
                size,
                size,
                0,
                NULL,
                DI_NORMAL
            );
        }

        Sleep(10);
    }

    ReleaseDC(NULL, hdc);
    return 0;
}
