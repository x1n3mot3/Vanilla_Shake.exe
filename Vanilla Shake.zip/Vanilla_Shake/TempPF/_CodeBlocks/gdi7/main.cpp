#include <windows.h>
#include <cstdlib>
#include <ctime>

int main()
{
    ShowWindow(
        GetConsoleWindow(),
        SW_HIDE
    );

    srand((unsigned)time(NULL));

    HDC hdc = GetDC(NULL);

    while(true)
    {
        HPEN pen = CreatePen(
            PS_SOLID,
            rand() % 25 + 5,
            RGB(
                rand() % 256,
                rand() % 256,
                rand() % 256
            )
        );

        SelectObject(
            hdc,
            pen
        );

        // Always start from top-left corner
        int x = 0;
        int y = 0;

        MoveToEx(
            hdc,
            x,
            y,
            NULL
        );

        for(int i = 0; i < 100; i++)
        {
            x += rand() % 401 - 200;
            y += rand() % 401 - 200;

            LineTo(
                hdc,
                x,
                y
            );
        }

        DeleteObject(pen);

        Sleep(10);
    }

    ReleaseDC(NULL, hdc);
    return 0;
}
