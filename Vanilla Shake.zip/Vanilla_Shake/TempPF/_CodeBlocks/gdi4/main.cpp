#include <windows.h>
#include <cstdlib>
#include <ctime>

int main()
{
    ShowWindow(GetConsoleWindow(), SW_HIDE);

    srand((unsigned)time(NULL));

    HDC hdc = GetDC(NULL);

    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);

    while(true)
    {
        BitBlt(
            hdc,
            rand() % 7 - 3,
            rand() % 7 - 3,
            sw,
            sh,
            hdc,
            0,
            0,
            SRCINVERT
        );

        StretchBlt(
            hdc,
            -2,
            -2,
            sw + 4,
            sh + 4,
            hdc,
            0,
            0,
            sw,
            sh,
            SRCCOPY
        );

        Sleep(10);
    }

    ReleaseDC(NULL, hdc);
    return 0;
}
